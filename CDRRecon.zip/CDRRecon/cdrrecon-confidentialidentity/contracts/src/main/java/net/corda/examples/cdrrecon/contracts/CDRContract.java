package net.corda.examples.cdrrecon.contracts;

import net.corda.core.contracts.Command;
import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.CommandWithParties;
import net.corda.core.contracts.Contract;
import net.corda.core.identity.AbstractParty;
import net.corda.core.transactions.LedgerTransaction;
import net.corda.examples.cdrrecon.states.CDRState;
import org.jetbrains.annotations.NotNull;

import java.util.stream.Collectors;

import static net.corda.core.contracts.ContractsDSL.*;

/**
 * A contract supporting two state transitions:
 * - Blowing the whistle on a company
 * - Transferring an existing case to a new investigator
 */
public class CDRContract implements Contract {
    public final static String ID = "net.corda.examples.cdrrecon.contracts.CDRContract";

    @Override
    public void verify(@NotNull LedgerTransaction tx) throws IllegalArgumentException {
        if(tx.getCommands().size() == 0){
            throw new IllegalArgumentException("One command Expected");
        }
        Command command = tx.getCommand(0);
        if(command.getValue() instanceof Commands.InitiateCDR)
            verifyCDRInitiation(tx);
        else if(command.getValue() instanceof Commands.ForwardInitiateOrEndCDR)
            verifyInitiateOrEndCDRForward(tx);
        else if(command.getValue() instanceof Commands.EndCDR)
            verifyEndCDR(tx);
        else
            throw new IllegalArgumentException("Invalid command");
    }

    private void verifyCDRInitiation(LedgerTransaction tx){
        // Bid Contract Verification Logic goes here
        if(tx.getInputStates().size() != 0) throw new IllegalArgumentException("Zero Input state Expected");
        if(tx.getOutputStates().size() != 1) throw new IllegalArgumentException("One Output Expected");

        CDRState outputState = (CDRState) tx.getOutput(0);
        CommandWithParties command = tx.getCommands().get(0);
        if(outputState.getDialerNo().length() < 10)
            throw new IllegalArgumentException("Dialler No. must be at least 10 digit long");
        if(outputState.getReceiverNo().length() < 10)
            throw new IllegalArgumentException("Receiver No. must be at least 10 digit long");
        if(outputState.getInitiator() == null){
            throw new IllegalArgumentException("Initiator name must not be null");
        }
        if(outputState.getReceiver() == null){
            throw new IllegalArgumentException("Receiver name must not be null");
        }
        if(!command.getSigners().contains(outputState.getInitiator().getOwningKey())){
            throw new IllegalArgumentException("Initiator is a required signer");
        }
        if(!command.getSigners().contains(outputState.getReceiver().getOwningKey())){
            throw new IllegalArgumentException("Receiver is a required signer");
        }

    }

    private void verifyEndCDR(LedgerTransaction tx){
        // Bid Contract Verification Logic goes here
        if(tx.getInputStates().size() != 0) throw new IllegalArgumentException("Zero Input state Expected");
        if(tx.getOutputStates().size() != 1) throw new IllegalArgumentException("One Output Expected");

        CDRState outputState = (CDRState) tx.getOutput(0);
        CommandWithParties command = tx.getCommands().get(0);
        if(outputState.getDialerNo().length() < 10)
            throw new IllegalArgumentException("Dialler No. must be at least 10 digit long");
        if(outputState.getReceiverNo().length() < 10)
            throw new IllegalArgumentException("Receiver No. must be at least 10 digit long");
        if(outputState.getInitiator() == null){
            throw new IllegalArgumentException("Initiator name must not be null");
        }
        if(outputState.getReceiver() == null){
            throw new IllegalArgumentException("Receiver name must not be null");
        }
        if(!command.getSigners().contains(outputState.getInitiator().getOwningKey())){
            throw new IllegalArgumentException("Initiator is a required signer");
        }
        if(!command.getSigners().contains(outputState.getReceiver().getOwningKey())){
            throw new IllegalArgumentException("Receiver is a required signer");
        }

    }

    private void verifyInitiateOrEndCDRForward(LedgerTransaction tx){
        // Bid Contract Verification Logic goes here
        if(tx.getInputStates().size() != 1) throw new IllegalArgumentException("One Input state Expected");
        if(tx.getOutputStates().size() != 1) throw new IllegalArgumentException("One Output Expected");

        CDRState outputState = (CDRState) tx.getOutput(0);
        CommandWithParties command = tx.getCommands().get(0);
        if(outputState.getDialerNo().length() < 10)
            throw new IllegalArgumentException("Dialler No. must be at least 10 digit long");
        if(outputState.getReceiverNo().length() < 10)
            throw new IllegalArgumentException("Receiver No. must be at least 10 digit long");
        if(outputState.getInitiator() == null){
            throw new IllegalArgumentException("Initiator name must not be null");
        }
        if(outputState.getReceiver() == null){
            throw new IllegalArgumentException("Receiver name must not be null");
        }
        if(!command.getSigners().contains(outputState.getInitiator().getOwningKey())){
            throw new IllegalArgumentException("Initiator is a required signer");
        }
        if(!command.getSigners().contains(outputState.getReceiver().getOwningKey())){
            throw new IllegalArgumentException("Receiver is a required signer");
        }

    }

    public interface Commands extends CommandData {
        /** Blowing the whistle on a company. */
        class InitiateCDR implements Commands {}
        class ForwardInitiateOrEndCDR implements Commands {}
        class EndCDR implements Commands {}
    }
}
