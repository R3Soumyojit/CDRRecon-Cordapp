package net.corda.examples.cdrrecon.states;

import com.google.common.collect.ImmutableList;
import net.corda.core.contracts.BelongsToContract;
import net.corda.core.contracts.LinearState;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.identity.AbstractParty;
import net.corda.core.identity.AnonymousParty;
import net.corda.examples.cdrrecon.contracts.CDRContract;
import org.jetbrains.annotations.NotNull;

import java.util.List;

@BelongsToContract(CDRContract.class)
public class CDRState implements LinearState {
    private final String dialerNo;
    private final String receiverNo;
    private String eventTime;
    private String callStatus;
    private AnonymousParty initiator;
    private AnonymousParty receiver;
    private List<AnonymousParty> signers;
    private String uniqueCallID;
    private final UniqueIdentifier linearId;

    public CDRState(String dialerNo, String receiverNo, String eventTime, String callStatus, AnonymousParty initiator, AnonymousParty receiver, List<AnonymousParty> signers, String uniqueCallID, UniqueIdentifier linearId) {
        this.dialerNo = dialerNo;
        this.receiverNo = receiverNo;
        this.eventTime = eventTime;
        this.callStatus = callStatus;
        this.initiator = initiator;
        this.receiver = receiver;
        this.signers = signers;
        this.uniqueCallID = uniqueCallID;
        this.linearId = linearId;
    }

    public String getDialerNo() {
        return dialerNo;
    }

    public String getReceiverNo() { return  receiverNo; };

    public  String getEventTime() { return  eventTime; };

    public  String getCallStatus() { return  callStatus; };

    public AnonymousParty getInitiator() {
        return initiator;
    }

    public AnonymousParty getReceiver() {
        return receiver;
    }

    public List<AnonymousParty> getSigners() { return signers; }

    public String getUniqueCallID() {
        return uniqueCallID;
    }

    @NotNull
    @Override
    public UniqueIdentifier getLinearId() {
        return linearId;
    }

    @NotNull
    @Override
    public List<AbstractParty> getParticipants() {
        return ImmutableList.of(initiator, receiver);
    }
}
