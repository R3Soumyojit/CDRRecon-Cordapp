package net.corda.examples.cdrrecon.flows;

import co.paralleluniverse.fibers.Suspendable;
import net.corda.confidential.SwapIdentitiesFlow;
import net.corda.core.flows.*;
import net.corda.core.transactions.SignedTransaction;
import org.jetbrains.annotations.NotNull;

@InitiatedBy(CDRInitiateOrEndCallForwardFlow.class)
public class CDRInitiateOrEndCallForwardFlowResponder extends FlowLogic<Void> {
    private final FlowSession counterpartySession;
    public CDRInitiateOrEndCallForwardFlowResponder(FlowSession counterpartySession) {
        this.counterpartySession = counterpartySession;
    }
    @Suspendable
    @Override
    public Void call() throws FlowException {
        boolean flag = counterpartySession.receive(Boolean.class).unwrap(it->it);
        if(flag) {
            subFlow(new SwapIdentitiesFlow(counterpartySession));
            SignedTransaction stx = subFlow(new SignTransactionFlow(counterpartySession) {
                @Override
                protected void checkTransaction(@NotNull SignedTransaction stx) throws FlowException {
                    // No checking need to be done.
                }
            });
        }
        subFlow(new ReceiveFinalityFlow(counterpartySession));
        return null;
    }
}
