package net.corda.examples.cdrrecon.flows;

import co.paralleluniverse.common.util.Pair;
import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import net.corda.confidential.SwapIdentitiesFlow;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.flows.*;
import net.corda.core.identity.AnonymousParty;
import net.corda.core.identity.Party;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;
import net.corda.examples.cdrrecon.contracts.CDRContract;
import net.corda.examples.cdrrecon.states.CDRState;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import org.jgroups.util.UUID;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.sql.Timestamp;
import java.time.Instant;

@InitiatingFlow
@StartableByRPC
public class CDRInitiateCallFlow extends FlowLogic<SignedTransaction> {
    private static final ProgressTracker.Step GENERATE_CONFIDENTIAL_IDS = new ProgressTracker.Step("Generating confidential identities for the transaction.") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return SwapIdentitiesFlow.tracker();
        }
    };
    private static final ProgressTracker.Step BUILD_TRANSACTION = new ProgressTracker.Step("Building the transaction.");
    private static final ProgressTracker.Step VERIFY_TRANSACTION = new ProgressTracker.Step("Verifying the transaction");
    private static final ProgressTracker.Step SIGN_TRANSACTION = new ProgressTracker.Step("I sign the transaction");
    private static final ProgressTracker.Step COLLECT_COUNTERPARTY_SIG = new ProgressTracker.Step("The counterparty signs the transaction") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return CollectSignaturesFlow.tracker();
        }
    };
    private static final ProgressTracker.Step FINALISE_TRANSACTION = new ProgressTracker.Step("Obtaining notary signature and recording transaction") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return FinalityFlow.tracker();
        }
    };

    private final ProgressTracker progressTracker = new ProgressTracker(
            GENERATE_CONFIDENTIAL_IDS,
            BUILD_TRANSACTION,
            VERIFY_TRANSACTION,
            SIGN_TRANSACTION,
            COLLECT_COUNTERPARTY_SIG,
            FINALISE_TRANSACTION
    );


    private final String dialerNo;
    private final String receiverNo;
    //private final Party initiator;
    private final Party receiver;

    public CDRInitiateCallFlow(String dialerNo, String receiverNo, Party receiver) {
        this.dialerNo = dialerNo;
        this.receiverNo = receiverNo;
    //  this.initiator = initiator;
        this.receiver = receiver;
    }

    @Nullable
    @Override
    public ProgressTracker getProgressTracker() {
        return progressTracker;
    }

    @Suspendable
    @Override
    public SignedTransaction call() throws FlowException {
        progressTracker.setCurrentStep(GENERATE_CONFIDENTIAL_IDS);
        FlowSession receiverSession = initiateFlow(receiver);

        /** Generates confidential identities for the initiator and the receiver. */
        LinkedHashMap<Party, AnonymousParty> confidentialIdentities = subFlow(new SwapIdentitiesFlow(
                receiverSession,
                GENERATE_CONFIDENTIAL_IDS.childProgressTracker()
        ));

        AnonymousParty anonymousInitiator = confidentialIdentities.get(getOurIdentity());
        AnonymousParty anonymousReceiver = confidentialIdentities.get(receiver);
        List<AnonymousParty> signers = new ArrayList<AnonymousParty>();
        signers.add(anonymousInitiator);
        signers.add(anonymousReceiver);
        Timestamp instant= Timestamp.from(Instant.now());
        String startTime = instant.toString();
        String status = "Start";
        UniqueIdentifier referenceUUID = new UniqueIdentifier();

        progressTracker.setCurrentStep(BUILD_TRANSACTION);

        CDRState output = new CDRState(dialerNo, receiverNo, startTime, status, anonymousInitiator, anonymousReceiver, signers, referenceUUID.toString(), referenceUUID);
        CommandData command = new CDRContract.Commands.InitiateCDR();

        // Obtain a reference to a notary we wish to use.
        /** METHOD 1: Take first notary on network, WARNING: use for test, non-prod environments, and single-notary networks only!*
         *  METHOD 2: Explicit selection of notary by CordaX500Name - argument can by coded in flow or parsed from config (Preferred)
         *
         *  * - For production you always want to use Method 2 as it guarantees the expected notary is returned.
         */
        final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0); // METHOD 1
        // final Party notary = getServiceHub().getNetworkMapCache().getNotary(CordaX500Name.parse("O=Notary,L=London,C=GB")); // METHOD 2

        TransactionBuilder txBuilder = new TransactionBuilder(notary)
                .addOutputState(output, CDRContract.ID)
                .addCommand(command, ImmutableList.of(anonymousInitiator.getOwningKey(), anonymousReceiver.getOwningKey()));

        progressTracker.setCurrentStep(VERIFY_TRANSACTION);
        txBuilder.verify(getServiceHub());

        progressTracker.setCurrentStep(SIGN_TRANSACTION);
        SignedTransaction stx = getServiceHub().signInitialTransaction(txBuilder, anonymousInitiator.getOwningKey());

        progressTracker.setCurrentStep(COLLECT_COUNTERPARTY_SIG);
        SignedTransaction ftx = subFlow(new CollectSignaturesFlow(
                stx,
                ImmutableList.of(receiverSession),
                ImmutableList.of(anonymousInitiator.getOwningKey()),
                COLLECT_COUNTERPARTY_SIG.childProgressTracker()
        ));

        progressTracker.setCurrentStep(FINALISE_TRANSACTION);
        return subFlow(new FinalityFlow(ftx, ImmutableList.of(receiverSession), FINALISE_TRANSACTION.childProgressTracker()));
    }
}
