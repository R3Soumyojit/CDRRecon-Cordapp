package net.corda.examples.cdrrecon.flows;

import co.paralleluniverse.common.util.Pair;
import co.paralleluniverse.fibers.Suspendable;
import com.google.common.collect.ImmutableList;
import net.corda.confidential.SwapIdentitiesFlow;
import net.corda.core.contracts.Command;
import net.corda.core.contracts.CommandData;
import net.corda.core.contracts.StateAndRef;
import net.corda.core.contracts.UniqueIdentifier;
import net.corda.core.flows.*;
import net.corda.core.identity.AnonymousParty;
import net.corda.core.identity.Party;
import net.corda.core.node.NodeInfo;
import net.corda.core.node.services.Vault;
import net.corda.core.node.services.vault.QueryCriteria;
import net.corda.core.transactions.SignedTransaction;
import net.corda.core.transactions.TransactionBuilder;
import net.corda.core.utilities.ProgressTracker;
import net.corda.examples.cdrrecon.contracts.CDRContract;
import net.corda.examples.cdrrecon.states.CDRState;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;

@InitiatingFlow
@StartableByRPC
public class CDRInitiateOrEndCallForwardFlow extends FlowLogic<SignedTransaction> {
    private static final ProgressTracker.Step GENERATE_CONFIDENTIAL_IDS = new ProgressTracker.Step("Generating confidential identities for the transaction.") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return SwapIdentitiesFlow.tracker();
        }
    };
    private static final ProgressTracker.Step BUILD_TRANSACTION = new ProgressTracker.Step("Building the transaction.");
    private static final ProgressTracker.Step VERIFY_TRANSACTION = new ProgressTracker.Step("Verifying the transaction");
    private static final ProgressTracker.Step SIGN_TRANSACTION = new ProgressTracker.Step("I sign the transaction");
    private static final ProgressTracker.Step COLLECT_COUNTERPARTY_SIG = new ProgressTracker.Step("The counterparty signs the transaction") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return CollectSignaturesFlow.tracker();
        }
    };
    private static final ProgressTracker.Step FINALISE_TRANSACTION = new ProgressTracker.Step("Obtaining notary signature and recording transaction") {
        @NotNull
        @Override
        public ProgressTracker childProgressTracker() {
            return FinalityFlow.tracker();
        }
    };
    private final ProgressTracker progressTracker = new ProgressTracker(
            GENERATE_CONFIDENTIAL_IDS,
            BUILD_TRANSACTION,
            VERIFY_TRANSACTION,
            SIGN_TRANSACTION,
            COLLECT_COUNTERPARTY_SIG,
            FINALISE_TRANSACTION
    );
    private final String uniqueCallID;
    private final String flag;
    private final Party newReceiver;
    public CDRInitiateOrEndCallForwardFlow(String uniqueCallID, String flag, Party newReceiver){
        this.uniqueCallID = uniqueCallID;
        this.flag = flag;
        this.newReceiver = newReceiver;
    }
    @Nullable
    @Override
    public ProgressTracker getProgressTracker() {
        return progressTracker;
    }
    @Suspendable
    @Override
    public SignedTransaction call() throws FlowException {
        progressTracker.setCurrentStep(GENERATE_CONFIDENTIAL_IDS);
        FlowSession receiverSession = initiateFlow(newReceiver);
        receiverSession.send(true);
        /** Generates confidential identities for the initiator and the receiver. */
        LinkedHashMap<Party, AnonymousParty> confidentialIdentities = subFlow(new SwapIdentitiesFlow(
                receiverSession,
                GENERATE_CONFIDENTIAL_IDS.childProgressTracker()
        ));
        AnonymousParty anonymousNewInitiator = confidentialIdentities.get(getOurIdentity());
        AnonymousParty anonymousNewReceiver = confidentialIdentities.get(newReceiver);
        QueryCriteria queryCriteria = new QueryCriteria.VaultQueryCriteria(Vault.StateStatus.UNCONSUMED);
        //retrieve the input state
        /*QueryCriteria queryCriteria = new QueryCriteria.LinearStateQueryCriteria(
                null,
                ImmutableList.of(linearId),
                Vault.StateStatus.UNCONSUMED,
                null);*/
        List<StateAndRef<CDRState>> CDRStates = getServiceHub().getVaultService().queryBy(CDRState.class, queryCriteria).getStates();
        if (CDRStates.size() < 1) {
            throw new FlowException(String.format(CDRStates.size() + CDRStates.toString()));
        }
        int counter = 0;
        int elemPosition = 0;
        for (StateAndRef<CDRState> cdrState: CDRStates){
            if(CDRStates.get(counter).getState().getData().getUniqueCallID().equals(uniqueCallID) && CDRStates.get(counter).getState().getData().getCallStatus().equals(flag))
                elemPosition = counter;
            else
                counter++;

        }
        CDRState inputState = CDRStates.get(elemPosition).getState().getData();
        String dialerNo = inputState.getDialerNo();
        String receiverNo = inputState.getReceiverNo();
        String startTime = inputState.getEventTime();
        String status = inputState.getCallStatus();
        UniqueIdentifier linearId = inputState.getLinearId();
        List<AnonymousParty> signers = new ArrayList<AnonymousParty>();
        for (AnonymousParty preSigner: inputState.getSigners()) {
            signers.add(preSigner);
        }
        signers.add(anonymousNewInitiator);
        signers.add(anonymousNewReceiver);
        progressTracker.setCurrentStep(BUILD_TRANSACTION);
        CDRState output = new CDRState(dialerNo, receiverNo, startTime, status, anonymousNewInitiator, anonymousNewReceiver, signers, uniqueCallID, linearId);
        CommandData command = new CDRContract.Commands.ForwardInitiateOrEndCDR();
        final Party notary = getServiceHub().getNetworkMapCache().getNotaryIdentities().get(0); // METHOD 1
        TransactionBuilder txBuilder = new TransactionBuilder(notary)
                .addInputState(CDRStates.get(0))
                .addOutputState(output, CDRContract.ID)
                .addCommand(command, ImmutableList.of(anonymousNewInitiator.getOwningKey(), anonymousNewReceiver.getOwningKey()));
        progressTracker.setCurrentStep(VERIFY_TRANSACTION);
        txBuilder.verify(getServiceHub());
        progressTracker.setCurrentStep(SIGN_TRANSACTION);
        SignedTransaction stx = getServiceHub().signInitialTransaction(txBuilder, anonymousNewInitiator.getOwningKey());
        progressTracker.setCurrentStep(COLLECT_COUNTERPARTY_SIG);
        SignedTransaction ftx = subFlow(new CollectSignaturesFlow(
                stx,
                ImmutableList.of(receiverSession),
                ImmutableList.of(anonymousNewInitiator.getOwningKey()),
                COLLECT_COUNTERPARTY_SIG.childProgressTracker()
        ));
        Party prevParty = getServiceHub().getIdentityService().wellKnownPartyFromAnonymous(inputState.getInitiator());
        FlowSession prevOwnerSession = initiateFlow(prevParty);
        prevOwnerSession.send(false);
        progressTracker.setCurrentStep(FINALISE_TRANSACTION);
        return subFlow(new FinalityFlow(ftx, ImmutableList.of(receiverSession, prevOwnerSession), FINALISE_TRANSACTION.childProgressTracker()));
    }
}